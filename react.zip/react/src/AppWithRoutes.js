import React, { Component, useSyncExternalStore } from "react";

import { Switch, Route, Redirect } from "react-router-dom";
import MyComp from "./components/componentBasics/MyComp";
import ConditionalContent from "./components/jsx/JSXExample";
import MyFuncComp from "./components/componentBasics/FunComponent";
import MyCompState from "./components/componentBasics/ClassComponent";
import EventHandling from "./components/componentBasics/EventHandling";
import LifeCycleEx from "./components/lifecycle/LifeCycleEx";
import ServiceCallEx from "./components/serviceCall/ServiceCallEx";
import StylesEx from "./components/styles/StylesEx";
// import MaterialUIEx from "./components/styles/MaterialUIEx";
import StatefullComponent from "./components/componentBasics/StatefullComponent";
import Parent from "./components/redux/calling/GrandParent";
import MyContextComp from "./components/contextComp/MyContextComp";
import PrintContextName from "./components/contextComp/PrintContextName";
import AppHooks from "./components/hooks/App";
import LifeCycleExHooks from "./components/hooks/LifeCycleExHooks";
import PdfPrint from "./components/pdf/PdfPrint";
import ReactPdf from "./components/pdf/ReactPdf";
import HOCEx from "./components/hoc/Parent";
import LifeCyclesHooks from "./components/hooks/LifeCyclesHooks";
import UseRefEx from "./components/hooks/UseRefEx";
import UseMemoEx from "./components/hooks/memo/Parent";
import UsePrevious from "./components/hooks/customHook/Parent";
import ConsumerContext from "./components/hooksWithFunctionalComps/useContext/consumer";
import ProviderContext from "./components/hooksWithFunctionalComps/useContext/provider";
import PersonalDetailsRed from "./components/redux/reduxHooks/PersonalDetailsRed";
import ParentTypeCheck from "./components/typeChecking/Parent";
import GlobalContextProvider from "./components/globalStateContextAPI/Parent";
import GlobalContextAPI from "./components/setGlobalContextAPI/Parent";
import GlobalContextAPI2 from "./components/setGlobalContextAPI/Child2";
import { GlobalContextProviderAPI } from "./components/setGlobalContextAPI/GlobalProvider";

import UseReducerEx from "./components/hooksWithFunctionalComps/UseReducerHook/useReducerEx";

import FormikEx from "./components/formik/FormikEx";

import PortalsEx from "./components/hooks/PortalsEx";

import CompositionEx from "./components/composition/CompositionEx";

import useCallbackEx from "./components/hooksWithFunctionalComps/useCallbackUseMemo/useCallbackEx";

import Download from "./Download";

import Stopwatch from "./components/proConcepts/Stopwatch";

import Timer from "./components/proConcepts/Timer";

class AppWithRoutes extends Component {
  render() {
    return (
      // <React.StrictMode>
      <GlobalContextProviderAPI>
        <Switch>
          {/* <Route component={} exact path="/" /> */}
          <Route component={CompositionEx} exact path="/CompositionEx" />
          <Route component={EventHandling} exact path="/eventHandle" />
          <Route component={ConditionalContent} exact path="/jsxex" />
          <Route
            component={StatefullComponent}
            exact
            path="/statefullComponent"
          />
          <Route component={PortalsEx} exact path="/PortalsEx" />
          <Route component={UseRefEx} exact path="/UseRefEx" />
          <Route component={LifeCyclesHooks} exact path="/LifeCyclesHooks" />
          <Route component={FormikEx} exact path="/FormikEx" />
          <Route component={UseReducerEx} exact path="/UseReducerEx" />
          <Route component={GlobalContextAPI} exact path="/globalState" /> //
          <Route component={GlobalContextAPI2} exact path="/globalState2" />
          <Route
            component={GlobalContextProvider}
            exact
            path="/GlobalContextProvider"
          />
          <Route component={UseMemoEx} exact path="/UseMemoEx" />
          <Route component={useCallbackEx} exact path="/useCallbackEx" />
          <Route component={ParentTypeCheck} exact path="/ParentTypeCheck" />
          <Route
            component={PersonalDetailsRed}
            exact
            path="/PersonalDetailsRed"
          />
          <Route component={ConsumerContext} exact path="/ConsumerContext" />
          <Route component={ProviderContext} exact path="/ProviderContext" />
          <Route component={UsePrevious} exact path="/UsePrevious" />
          <Route component={ReactPdf} exact path="/ReactPdf" />
          <Route component={PdfPrint} exact path="/PdfPrint" />
          <Route component={HOCEx} exact path="/hocex" />
          <Route component={Download} exact path="/download" />
          <Route component={Stopwatch} exact path="/stopwatch" />
          <Route component={Timer} exact path="/timer" />
          //Old routes
          <Route component={AppHooks} exact path="/apphooks" />
          <Route component={LifeCycleExHooks} exact path="/lifehooks" />
          <Route component={MyContextComp} exact path="/contextmy" />
          <Route component={PrintContextName} exact path="/contextprint" />
          <Route component={MyComp} exact path="/myComp" />
          <Route component={Parent} exact path="/dataFlow" />
          <Route component={MyFuncComp} exact path="/myFunComp" />
          <Route component={MyCompState} exact path="/myCompState" />
          <Route component={LifeCycleEx} exact path="/lifeCycle" />
          <Route component={ServiceCallEx} exact path="/serviceCallEx" />
          <Route component={StylesEx} exact path="/stylesEx" />
          {/* <Route component={MaterialUIEx} exact path="/materialUIEx" /> */}
        </Switch>
      </GlobalContextProviderAPI>
      // </React.StrictMode>
    );
  }
}

export default AppWithRoutes;

//package-lock.json should not be in gitignore
//It has locked version of package versions
//if package.json has ~/^ then npm install can be changed. That would be updated in lock json

//npx: execute using npm

//Webpack is a bundler:
//hot module reload: HMR: webpack does that
//File watchers algo does that
// bundling to css,js and html files
//dev nd prod builds
// Image optimization
// Caching while in development so that build is fast second time onwards
// compression
// Compatible with old browsers
//consistent hashing algo used for this
//transitive dependency: npm takes care of that
//Tree shaking: remove which function are not used while bundling.

//anything we can generate in server , we ll keep in gitignore

//react with other library makes it faster

//We need to convert our code to older versions of code so all browsers can understand

//babel-plugin-transform-remove-console: to remove console in prod build

//react key reconcilation:  If we have multiple children without key then for rerendering react has to update all DOM becoz
// react cant distinguish which is added, so we have to add a key
// We should not use index as key

//React.createElement => objectc => HTML(DOM)

// JSX: Motive of react team is to write html using JS

// React Component:
// react element rendering is just giving name but react component we have to render like <ReactComponent/> as tag

// JSX can have only one parent
// Fragment is component which used to wrap multiple components without div

//config driven UI

/*** Virtual DOM:
 * Virtual DOM is a representation of real DOM,
 * whenever any change is happening, diff algo is used for reconcialition
 * where they compare which part react wants to rerender, that part is only rerendered.
 * if we give keys its easy for react to only add particularextra element
 */

// React fiber: new reconcialitation engine

/**
 * Named import & default import
 * we can do one: export default Comp1 ----default import
 * multiple : export const Comp2 =()=>() ---Named import
 *
 */

/**
 * Chunking
 * Code splitting
 * dynamic bundling
 * lazy loading
 * on demand loading
 * dynamic import
 *
 */

/**
 * CSS framework:
 * optimized css
 *
 * types: scss,inline,material-ui(pros: reusable)
 */

/**
 * redux:
 * redux cons: setup
 * redux toolkit pros: easy to use
 * architecture:
 * store is a big object
 * create slices of store: eg user,cart
 * to update a slice dispatch an action =>action ll call a fun, fun ll modify the slice.
 * the fun is called reducer
 *
 *
 *
 */

/**
 * N level nested comments
 * caching in UI like live comments, reels
 *
 */

// Design priciples:
/**
reusable comp
high cohesive with minimal coupling
better way to share logic between comp
 */

/**
 * Design patterns:
 *HOC pattern
 Render props pattenrn: a prop in a comp which is a func and that returns a JSX
 Compound pattern: multiple components come together to serve a common functionlaity (Tabs component)
 react hooks pattern

 */

/**
 *strictmode: When we wrap our components inside strict mode,
 it identifies components with unsafe lifecycles etc.

scaler values ex: 12,10,true,false,"words" 
these are evaluated by values.
12===12, "jane"==="jane",true===true : are all true
but when we pass an object to child comp, the child comp is in dependecy with useEffect inside child comp
then it ll re render many times. so try to give scalar values not the whole objects
 */

/**
 * react batch update is by default with react 18
 */

/**
 * useSyncExternalStore
 */

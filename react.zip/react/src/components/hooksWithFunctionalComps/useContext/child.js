import React, { useContext } from "react";
import PrintName from "./consumer";
import context from "./context";
const MyContextCompChild = () => {
  let value = useContext(context);
  return (
    <div>
      <context.Provider value={{...value,...{"child":"child"}}}>
        <h1>Middle Component</h1>
        <PrintName />
      </context.Provider>
    </div>
  );
};

export default MyContextCompChild;

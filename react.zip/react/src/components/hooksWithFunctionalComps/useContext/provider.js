import React, { useState ,useContext} from "react";
import { NavLink } from "react-router-dom";

import context from "./context";
import MyContextCompChild from "./child";

import MyCompContxt from "./context";
import LastComp from "./lastComponent"




const MyContextComp = () => {
  const [provider, setProvider] = useState({});
  const  [name, setName] = useState("sreeja");

  let value=useContext(context);
  console.log("value in provider",context)
  const handleChange = () => {
    let random = Math.random();
    setProvider({...value,...{"random":random}});
  };
  return (
    <div>
      <h1>Provider Component</h1>
      <context.Provider value={provider}>
        <MyContextCompChild />
      </context.Provider>
      <button onClick={handleChange}>Change</button>
      {/* <NavLink to="/reducer">
        move to reducer
      </NavLink> */}
    </div>
  );
};

export default MyContextComp;

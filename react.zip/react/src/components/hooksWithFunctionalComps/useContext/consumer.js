import React, { useState,useContext } from "react";
import MyCompContxt from "./context";
import LastComp from "./lastComponent"

const PrintContextName = () => {
  let value=useContext(MyCompContxt);
  console.log("value",value)
  return (
    <div>
      {/* <MyCompContxt.Consumer>
        {(value) => {
          return <h2>Consumer component, value is {value}</h2>;
        }}
      </MyCompContxt.Consumer> */}
      <LastComp />
      {/* Using useContext {value} */}
    </div>
  );
};

export default PrintContextName;

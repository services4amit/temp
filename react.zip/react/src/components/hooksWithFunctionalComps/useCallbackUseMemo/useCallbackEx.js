import React, { useCallback, useState } from "react";

const useCallbackEx = (props) => {
  const [countOne, setCountOne] = useState(0);
  const [countTwo, setCountTwo] = useState(0);
  console.log("Comp rendered");

  const handler1 = () => {
    console.log("inside handler1");
    setCountOne(countOne + 1);
  };

  const handler2 = () => {
    console.log("inside handler2");
    setCountTwo(countTwo + 1);
  };

  const memohandler1 = useCallback(() => {
    console.log("inside handler1");
    setCountOne(countOne + 1);
  }, [countOne]);

  const memohandler2 = useCallback(() => {
    console.log("inside handler2");
    setCountTwo(countTwo + 1);
  }, [countTwo]);

  return (
    <>
      {/* <Button handler={handler1} name="1" namee={countOne}>
        Button1
      </Button>
      <Button handler={handler2} name="2" namee={countTwo}>
        Button2
      </Button> */}
      <Button handler={memohandler1} namee={countOne} name="1">
        Button1
      </Button>
      <Button handler={memohandler2} namee={countTwo} name="2">
        Button2
      </Button>
    </>
  );
};
const Button = React.memo(({ name, handler, namee }) => {
  console.log("Child Comp", name);

  function hnadleonMouseOver() {
    console.log("hover");
  }
  return (
    <button
      // onMouseOver={() => hnadleonMouseOver()}
      // onMouseOut={() => console.log("out")}
      onClick={handler}
    >
      {namee}
    </button>
  );
});
export default useCallbackEx;

// We are using memo, so the child component should not re-render since neither
//  the  state nor the passing function are changing when the count is incremented.

// This is because of something called "referential equality".

// Every time a component re-renders,
//  its functions get recreated. Because of this, the passing function has actually changed.

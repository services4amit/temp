import React, { useState, Fragment, useRef, useEffect } from "react";
const Previous = (value) => {
    console.log({value})
    const ref = useRef(null);

    useEffect(() => {
        console.log("use effect",value)
        ref.current = value;
    })
    console.log({ref})
    return ref.current;
}

export default Previous;
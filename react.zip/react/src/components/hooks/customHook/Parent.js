import React, { useState, Fragment, useMemo } from "react";
import usePrevious from "./Previous";

const Parent = () => {
  const [count, setCount] = useState(0);
  const prev = usePrevious(count);
  console.log({ prev });
  const addCount = () => {
    setCount(count + 1);
  };

  console.log({ count });
  return (
    <Fragment>
      Count is {count}
      <button onClick={addCount}>Add</button>
      Prev is {prev}
    </Fragment>
  );
};

export default Parent;

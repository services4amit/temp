import React, { Fragment, useEffect, useRef } from "react";
import ForwardRefEx from "./ForwardRefEx";

/**
 * Keeping track of html element
 * keep value of an element but dont rerender when value changes
 *
 */
// ref is reference of html element
// we can read values from there ref.current.value
// we can manipulate ref.current.focus() etc
function UseRefEx() {
  const nameRef = useRef();
  const passRef = useRef();
  const idRef = useRef();
  const divRef = useRef();
  const C1Ref = useRef(null);

  useEffect(() => {
    C1Ref.current.focus();
  }, []);

  const onChangeHandler = (e) => {
    console.log(18, e);
    if (e.key === "Enter") {
      switch (e.target.name) {
        case "user":
          idRef.current.focus();
          break;
        case "id":
          passRef.current.focus();
          break;
        default:
          useRef.current.focus();
      }
    }
  };

  const c1Down = () => {
    passRef.current.focus();
  };
  return (
    <Fragment>
      <div ref={divRef}>
        <h1>UseRef</h1>
        <span>User</span>{" "}
        <input
          name="user"
          onKeyPress={(e) => onChangeHandler(e)}
          ref={nameRef}
        ></input>
        <span>ID</span>{" "}
        <input
          name="id"
          onKeyPress={(e) => onChangeHandler(e)}
          ref={idRef}
        ></input>
        <span>Pass</span> <input name="pass" ref={passRef}></input>
        <ForwardRefEx
          placeholder="enter c1"
          onKeyDown={onChangeHandler}
          ref={C1Ref}
          c1Down={c1Down}
        ></ForwardRefEx>
      </div>
    </Fragment>
  );
}

export default UseRefEx;

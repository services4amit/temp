import React, { useState, Fragment, useMemo } from "react";
import ReactDOM from "react-dom";

const Modal = (props) => {
  return (
    <>
      <div
        style={{
          color: "red",
          position: "absolute",
          top: "0",
          left: "0",
          bottom: "0",
          right: "0",
        }}
      ></div>
      <div style={{ color: "blue" }}>Modal is {props.name}</div>
    </>
  );
};

export default Modal;

import React, { useState, Fragment, useMemo } from "react";
import ReactDOM from "react-dom";
import Modal from "./Modal";

const PortalsEx = () => {
  const [visibility, setVisibility] = useState("hidden");
  const handleClick = () => {
    if (visibility === "hidden") {
      //if the visibility state is 'hidden'
      setVisibility("visible"); //then set it to 'visible'
    } else {
      setVisibility("hidden"); //otherwise, make it 'hidden'
    }
  };
  return (
    <div className="App">
      <button onClick={() => handleClick()}>Show/Hide</button>
      {/*The visibility of the modal*/}
      <div style={{ visibility }}>
        <Modal name="basic"></Modal>
      </div>
      <button onClick={() => handleClick()}>Show/Hide Portal</button>
      {/*The visibility of the modal*/}

      {/* {
        // <div id="portal-div"></div> added a portal so it wont come under "root" div
        // so no complexity for making modals
        visibility == "visible" &&
          ReactDOM.createPortal(
            <div>
              <Modal name="portal"></Modal>
            </div>,
            document.getElementById("portal-div")
          )
      } */}
    </div>
  );
};

export default PortalsEx;

import React, { useState, Fragment } from "react";
const Child = (props) => {
  const [count, setCount] = useState(0);

  const addCount = () => {
    setCount(count + 1);
  };
  console.log(props.text, props.count);
  return (
    <Fragment>
      Child-{props.text}
      {props.count}
    </Fragment>
  );
};

export default Child;

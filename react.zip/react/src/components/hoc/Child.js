import React from "react";

import withResponseCheck from "./HOCError";

const Child = (props) => {
  return (
    <div>
      Child
      <p>{props.resp ? props.resp.msg : null}</p>
    </div>
  );
};

// export default withResponseCheck(Child);
export default Child;

import React from "react";

const check = (props) => {
  let err = {
    code: 500,
    msg: "FAILED",
  };

  let obj = {
    code: 200,
    msg: "SUCCESS",
  };
  if (props.status == "ERROR") {
    let resp = { ...props, resp: err };
    console.log("inside hoc", resp);
    return resp;
  } else {
    return { ...props, resp: obj };
  }
};

// https://www.smashingmagazine.com/2020/06/higher-order-components-react/
//we receive the Basecomponent
const withResponseCheck = (BaseComponent) => {
  //return a new function with added props as per need
  return (props) => {
    const new_props = check(props);
    // Component with modified props will be called whereever we are calling the Basecomponent
    return <BaseComponent {...new_props} />;
  };
};

export default withResponseCheck;

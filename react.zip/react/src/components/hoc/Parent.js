import React from "react";

import Child from "./Child";
import withResponseCheck from "./HOCError";

const EnhancedChild = withResponseCheck(Child);

const Parent = () => {
  // window.onafterprint
  return (
    <div>
      <h1>Parent</h1>
      <EnhancedChild status="a"></EnhancedChild>
      {/* <Child status="a"></Child> */}
    </div>
  );
};

export default Parent;

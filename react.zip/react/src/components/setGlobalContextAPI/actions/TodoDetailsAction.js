export const addTodo = (data) => {
  let obj = {
    todo: {
      type: "ADD_TODO",
      payload: data,
      red: "TODO",
    },
  };
  return {
    type: "ADD_TODO",
    payload: data,
    red: "TODO",
  }
};

export const addNewTodo = (data) => {
  return {
    type: "ADD_TODO_NEW",
    payload: data,
  };
};

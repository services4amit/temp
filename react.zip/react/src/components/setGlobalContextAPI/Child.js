import React, { useContext,memo } from "react";
import { GlobalContext } from "./GlobalProvider";
import { useStateValue } from './GlobalProvider';
import Child2 from './Child2'

function Child() {
  console.count("Child")
  const [{ app }, dispatch] = useStateValue();

  // const value = useContext(GlobalContext);
  // const [state,dispatch] = useContext(GlobalContext);
  // console.log("value in Child", value);
  return <div className="App">Child {app}
  <Child2></Child2>
  </div>;
}

export default Child;


const initState = {
  app: "react-context-api",
  todos: [
    {
      id: 0,
      text: "Learn React hooks",
    },
  ],
  todos_new: [
    {
      id: 0,
      text: "Learn Nodejs",
    },
  ]
};

const red = (state=initState, action) => {
  console.log("td",state)
  switch (action.type) {
    case "ADD_TODO_NEW":
      return { ...state, todos_new: [...state.todos_new, action.payload] };
    default:
      throw new Error();
  }
};

export default red;
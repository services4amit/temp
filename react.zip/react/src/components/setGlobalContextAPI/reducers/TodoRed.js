const initState = {
  app: "react-context-api",
  todos: [
    {
      id: 0,
      text: "Learn React hooks",
    },
  ],
  todos_new: [
    {
      id: 0,
      text: "Learn Nodejs",
    },
  ]
};


const red = (state=initState, action) => {
  console.log("td",action)
  switch (action.todo.type) {
    case "ADD_TODO":
      return { ...state, todos: [...state.todos, action.payload] };
    default:
      throw new Error();
  }
};

export default red;
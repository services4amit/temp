import React, { useReducer, createContext,useContext } from "react";
import { combineReducers } from 'redux';
import todoReducer from './reducers/TodoRed'
import todoNewReducer from './reducers/TodoNewRed'

// Create Context Object
export const GlobalContext = createContext();

const initState = {
  app: "react-context-api",
  todos: [
    {
      id: 0,
      text: "Learn React hooks",
    },
  ],
  todos_new: [
    {
      id: 0,
      text: "Learn Nodejs",
    },
  ]
};




const reducer = (state, action) => {
  // console.log("initstate", initState);
  // console.log("state", state);
  // console.log("action", action);
  switch (action.type) {
    case "ADD_TODO":
      return { ...state, todos: [...state.todos, action.payload] };
    case "DONE_TODO":
      return {
        ...state,
        todos: state.todos.filter((todo) => todo.id !== action.payload),
      };
    case "ADD_TODO_NEW":
      return { ...state, todos_new: [...state.todos_new, action.payload] };
    default:
      throw new Error();
  }
};


const mainReducer=({todo,todo_new},action)=>({
  todo: todoReducer(todo, action),
  todo_new: todoNewReducer(todo_new, action)
  // switch (action.type) {
  //   case "ADD_TODO":
  //     return { ...state, todos: [...state.todos, action.payload] };
  //   case "DONE_TODO":
  //     return {
  //       ...state,
  //       todos: state.todos.filter((todo) => todo.id !== action.payload),
  //     };
  //   case "ADD_TODO_NEW":
  //     return { ...state, todos_new: [...state.todos_new, action.payload] };
  //   default:
  //     throw new Error();
  // }
})


// Create a provider for components to consume and subscribe to changes
export const GlobalContextProviderAPI = (props) => {
  const [state, dispatch] = useReducer(reducer, initState);
  // const [state, dispatch] = useReducer(mainReducer, initState);
  

  return (
    <GlobalContext.Provider value={[state, dispatch]}>
      {props.children}
    </GlobalContext.Provider>
  );
};

export const useStateValue = () => useContext(GlobalContext);
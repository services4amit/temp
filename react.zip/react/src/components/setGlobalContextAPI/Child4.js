import React, { useContext, memo } from "react";
import { addNewTodo } from "./actions/TodoDetailsAction";
import { useStateValue } from "./GlobalProvider";
function Child4() {
  const [{ todos_new, todos }, dispatch] = useStateValue();

  // console.log("value in Child4 state.todo.app}", state.todo.app);
  console.count("Child4");
  const handleClick = () => {
    let payload = {
      text: "reading",
      id: new Date(),
    };
    dispatch(addNewTodo(payload));
  };
  return (
    <div className="App">
      Child4{" "}
      {todos_new.map((d) => (
        <h2>{d.text}</h2>
      ))}
      {todos.map((d) => (
        <h2>{d.text}</h2>
      ))}
      <button onClick={handleClick}>Click 4</button>
    </div>
  );
}

export default memo(Child4);

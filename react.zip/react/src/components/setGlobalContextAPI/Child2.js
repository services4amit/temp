import React, { useContext } from "react";
import Child from "./Child";
import { useStateValue } from "./GlobalProvider";
import Child4 from "./Child4";
import { addTodo } from "./actions/TodoDetailsAction";
function Child2() {
  const [{ todos }, dispatch] = useStateValue();

  // const value = useContext(GlobalContext);
  // const [state,dispatch] = useContext(GlobalContext);
  // console.log("value in Child2", value);
  // console.log("state in Child2", dispatch);
  console.count("Child2")
  const handleClick = () => {
    let payload = {
      text: "texting",
      id: new Date(),
    };
    dispatch(addTodo(payload));
  };
  return (
    <div className="App">
      Child2
      {todos.map((d) => (
        <h2>{d.text}</h2>
      ))}
      <button onClick={handleClick}>Click</button>
      <Child4></Child4>
    </div>
  );
}

export default Child2;

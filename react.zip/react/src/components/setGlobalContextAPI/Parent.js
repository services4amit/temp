import React from "react";
import { GlobalContextProvider } from "./GlobalProvider";
import Child from "./Child";
import Child2 from "./Child2";

function Parent() {
  console.count("Parent")
  return (
    <div className="App">
      {/* not required becoz its given globally for all routes */}
      {/* <GlobalContextProvider> */}
        <Child />
      {/* </GlobalContextProvider> */}
    </div>
  );
}

export default Parent;

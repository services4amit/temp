// import { useState } from "react";
import React, { useCallback, useEffect, useState } from "react";

const BadStopwatch = () => {
  const [time, setTime] = useState(0);

  console.count("Stopwatch");

  useEffect(() => {
    setInterval(() => {
      setTime((prev) => prev + 0.1);
    }, 100);
  }, []);

  return <>Stopwatch {time}</>;
};

const GoodStopwatch = () => {
  const [time, setTime] = useState(0);

  console.count("GoodStopwatch");

  useEffect(() => {
    let interval = setInterval(() => {
      setTime((prev) => prev + 0.1);
    }, 100);

    return () => {
      clearInterval(interval);
    };
  }, []);

  return <>Stopwatch {time}</>;
};

export default function App() {
  return (
    <>
      <div>
        BAD <BadStopwatch></BadStopwatch>
      </div>
      <div>
        Good <GoodStopwatch></GoodStopwatch>
      </div>
    </>
  );
}

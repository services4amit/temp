// import { useState } from "react";
import React, { useCallback, useEffect, useState } from "react";
let timerId = 0;
const GoodStopwatch = () => {
  const [time, setTime] = useState(0);

  console.count("GoodStopwatch");

  useEffect(() => {
    timerId++;
    let interval = setInterval(() => {
      setTime((prev) => {
        console.log(`timer id ${timerId} starts ${prev}`);
        return prev + 1;
      });
    }, 1000);

    //if we dont add below code we ll get warning as older comp is not removed
    return () => {
      clearInterval(interval);
    };
  }, []);

  return <>Stopwatch {time}</>;
};

export default function App() {
  const [index, setIndex] = useState(0);
  return (
    <>
      <div>
        Good <GoodStopwatch key={index}></GoodStopwatch>
        <br />
        <button onClick={() => setIndex(index + 1)}>Update index</button>
      </div>
    </>
  );
}

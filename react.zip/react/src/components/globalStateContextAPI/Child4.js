import React, { useContext } from "react";
import { GlobalContext } from "./GlobalProvider";

function Child4() {
  const value = useContext(GlobalContext);
  const [state,dispatch] = useContext(GlobalContext);
  console.log("value in Child4", value);
  // console.log("value in Child4 state.todo.app}", state.todo.app);
  return <div className="App">Child4{state.app}</div>;
}

export default Child4;

const red = (state, action) => {
  console.log("2",state);
  return {"changed"}
  // switch (action.type) {
  //   case "CHANGE_APP":
  //     return { ...state, todos: [...state.todos, action.payload] };
  //   default:
  //     throw new Error();
  // }
};

export default red;
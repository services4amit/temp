const red = (state, action) => {
  console.log("td",state)
  switch (action.type) {
    case "ADD_TODO":
      return { ...state, todos: [...state.todos, action.payload] };
    default:
      throw new Error();
  }
};

export default red;
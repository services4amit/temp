import React, { useContext } from "react";
import Child from "./Child";
import { GlobalContext } from "./GlobalProvider";
import Child4 from './Child4'
import {addTodo} from './actions/TodoDetailsAction'
function Child2() {
  const value = useContext(GlobalContext);
  const [state,dispatch] = useContext(GlobalContext);
  console.log("value in Child2", value);
  console.log("state in Child2", state);
  const handleClick=()=>{
   let payload={
      text:"texting",
      id: new Date(),
    }
    dispatch(addTodo(payload));

    // dispatch({
    //   type: "ADD_NEW",
    //   payload: {
    //     text:"texting",
    //     id: new Date(),
    //   },
    // });
  }
  return <div className="App">Child2
  
  <button onClick={handleClick}>Click</button>
  <Child4></Child4>
  </div>;
}

export default Child2;

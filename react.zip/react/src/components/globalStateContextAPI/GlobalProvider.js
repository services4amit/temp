import React, { useReducer, createContext } from "react";
import { combineReducers } from 'redux';

// import todoRed from './reducers/TodoRed';
// import appRed from "./reducers/AppRed"
// Create Context Object
export const GlobalContext = createContext();

const initState = {
  app: "react-context-api",
  todos: [
    {
      id: 0,
      text: "Learn React hooks",
    },
  ],
};




const reducer = (state, action) => {
  console.log("initstate", initState);
  console.log("state", state);
  console.log("action", action);
  switch (action.type) {
    case "ADD_TODO":
      return { ...state, todos: [...state.todos, action.payload] };
    case "DONE_TODO":
      return {
        ...state,
        todos: state.todos.filter((todo) => todo.id !== action.payload),
      };
    case "ADD_NEW":
      return { ...state, result: "SUCCESS" };
    default:
      throw new Error();
  }
};


// const reducer=(state,action)=>{
//   console.log("42",state)
//   switch(action.red){
//     case "TODO":
//     return todoRed(state,action)
//   }
// }

// const reducer=({app,todos},action)=>({
//   app: appRed(app,action),
//   todos: todoRed(todos,action)
// })


// Create a provider for components to consume and subscribe to changes
export const GlobalContextProvider = (props) => {
  const [state, dispatch] = useReducer(reducer, initState);
  

  return (
    <GlobalContext.Provider value={[state, dispatch]}>
      {props.children}
    </GlobalContext.Provider>
  );
};

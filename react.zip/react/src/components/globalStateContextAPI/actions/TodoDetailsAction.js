export const addTodo=(data)=>{
    return {
        type:'ADD_TODO',
        payload:data,
        red:"TODO"
    }
}

export const deleteTodo=(data)=>{
    return {
        type:'DONE_TODO',
        value:data
    }
}
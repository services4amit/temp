import React from "react";
import { GlobalContextProvider } from "./GlobalProvider";
import Child from "./Child";

function Parent() {
  return (
    <div className="App">
      <GlobalContextProvider>
        <Child />
      </GlobalContextProvider>
    </div>
  );
}

export default Parent;

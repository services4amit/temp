import React, { useState } from "react";

const HooksTest = () => {
  const [text, showText] = useState(false);

  return <div>{showText ? <h1>Hello</h1> : <h1>Hi</h1>}</div>;
};

export default HooksTest;

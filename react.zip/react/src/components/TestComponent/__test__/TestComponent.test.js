import React from 'react';
import ReactDom from 'react-dom';
import {shallow} from 'enzyme'
import TestComponent from '../TestComponent';
import CommentList from '../../CommentList/CommentList'
import CommentBox from '../../CommentBox/CommentBox'

it('First test',()=>{
    // const div=document.createElement('div');
    // ReactDom.render(<TestComponent></TestComponent>,div);

    // console.log("print",div.innerHTML)
    // expect(div.innerHTML).toContain('Tsest')
    // ReactDom.unmountComponentAtNode(div);


})
let wrapped;
beforeEach(()=>{
    wrapped=shallow(<TestComponent></TestComponent>)
})

it('shows CommentBox',()=>{
    // const wrapped=shallow(<TestComponent></TestComponent>);
    expect(wrapped.find(CommentBox).length).toEqual(1)
})

it('shows Commentlist',()=>{
    // const wrapped=shallow(<TestComponent></TestComponent>);
    expect(wrapped.find(CommentList).length).toEqual(1)
})
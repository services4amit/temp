import React from "react";
import { shallow } from "enzyme";
import { shallowToJson } from "enzyme-to-json";
import { iterateObserversSafely } from "@apollo/client/utilities";
import HooksTest from './HooksTest'

it("hooks test",()=>{

    let component = shallow(<HooksTest/>);
    const confirm=jest.fn();
    React.useState=jest.fn(()=>["",confirm])
})
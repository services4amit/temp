import React, { useState } from "react";
import {
  CELL_CLASSES,
  CELL_ICON_TYPE,
  CELL_RENDERERS,
  COLUMN_TYPES,
  Table,
  TABLE_LAYOUT_OPTIONS,
} from "@cdk-rds/table";

import CommentList from 'components/CommentList/CommentList'
import CommentBox from 'components/CommentBox/CommentBox'

const TestComponent = () => {
  const [searchInputValue, setSearchInputValue] = useState();

  const handleSearchInputChange = (newValue) => {
    setSearchInputValue(newValue);
  };
  const columns = [
    {
      cellRenderer: CELL_RENDERERS.TEXT,
      field: "make",
      headerName: "Make",
      minWidth: 150,
      sortable: true,
    },
    {
      cellRenderer: CELL_RENDERERS.TEXT,
      field: "model",
      headerName: "Model of the car",
      minWidth: 50,
      width: 300,
    },
    {
      cellClass: [CELL_CLASSES.ALIGN_CELL_RIGHT, CELL_CLASSES.NUMERIC_CELL],
      cellRenderer: CELL_RENDERERS.TEXT,
      field: "year",
      filter: "agNumberColumnFilter",
      headerName: "Year",
      headerTooltip: "Year of production",
      minWidth: 100,
      sortable: true,
      sortingOrder: ["desc", "asc", null],
      type: COLUMN_TYPES.NUMERIC_COLUMN,
    },
    {
      cellClass: [CELL_CLASSES.ALIGN_CELL_RIGHT, CELL_CLASSES.NUMERIC_CELL],
      cellRenderer: CELL_RENDERERS.TEXT,
      field: "price",
      headerName: "Price",
      minWidth: 100,
      sortable: true,
      sortingOrder: ["desc", "asc", null],
      type: COLUMN_TYPES.NUMERIC_COLUMN,
    },
    {
      cellRenderer: CELL_RENDERERS.ICON,
      cellRendererParams: {
        rendererIcon: CELL_ICON_TYPE.STAR,
      },
      field: "rating",
      headerName: "Custom icon",
      minWidth: 128,
    },
    {
      cellRenderer: CELL_RENDERERS.RATING,
      field: "rating",
      headerName: "Rating",
      minWidth: 128,
    },
    {
      cellClass: [CELL_CLASSES.ALIGN_CELL_RIGHT, CELL_CLASSES.NUMERIC_CELL],
      cellRenderer: (params) => params.value * params.value,
      field: "custom",
      headerName: "Custom",
      minWidth: 100,
    },
  ];
  const data = [
    {
      button: {
        href: "http://www.cdk.com",
        label: "Porsche",
      },
      custom: 8,
      link: {
        href: "http://www.cdk.com",
        label: "Porsche",
      },
      make: "Porsche",
      model: "Boxter",
      price: 72000,
      rating: 4,
      year: 2018,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "BMW",
      },
      custom: 10,
      link: {
        href: "http://www.cdk.com",
        label: "BMW",
      },
      make: "BMW",
      model: "530",
      price: 45000,
      rating: 4,
      year: 2019,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },

    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
    {
      button: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      custom: 16,
      link: {
        href: "http://www.cdk.com",
        label: "VW",
      },
      make: "Volkswagen",
      model: "T-Roc",
      price: 22000,
      rating: 3,
      year: 2020,
    },
  ];

  const myTable = () => {
    return (
      <Table
        columns={columns}
        data={data}
        defaultPaginationPageSize={{
          label: "5",
          value: 5,
        }}
        disableColumnsMove={false}
        enableFilter
        hasPagination={true}
        headerTitle="Table with auto height"
        id="table-with-auto-height-1"
        onSearchInputChange={handleSearchInputChange}
        resizableHeaders
        searchInputName="table-search-input-name"
        searchInputValue={searchInputValue}
        tableLayout={TABLE_LAYOUT_OPTIONS.AUTO_HEIGHT}
      ></Table>
    );
  };

  const myText = () => {
    return <h1>TEXT</h1>;
  };
  return (
    <div>
      Test
      <CommentBox>

      </CommentBox>
      <CommentList></CommentList>
      {/* <Table
        columns={columns}
        data={data}
        defaultPaginationPageSize={{
          label: "5",
          value: 5,
        }}
        disableColumnsMove={false}
        enableFilter
        hasPagination={true}
        headerTitle="Table with auto height"
        id="table-with-auto-height-1"
        onSearchInputChange={handleSearchInputChange}
        resizableHeaders
        searchInputName="table-search-input-name"
        searchInputValue={searchInputValue}
        tableLayout={TABLE_LAYOUT_OPTIONS.AUTO_HEIGHT}
      ></Table> */}
      {/* {myTable()}
      {myText()} */}
    </div>
  );
};

export default TestComponent;

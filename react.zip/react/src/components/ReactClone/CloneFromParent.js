const CloneFromParent = () => {
  const childrenWithProps = React.Children.map(children, (child) => {
    return React.cloneElement(child, {
      userDetails: userDetails,
      dummy: "dummy",
    });
  });
  return <>{childrenWithProps}</>;
};

export default CloneFromParent;

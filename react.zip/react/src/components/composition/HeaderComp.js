import React from "react";
import Child1 from "./Child1";
import Child2 from "./Child2";

//building UI from smaller buidling blocks is called composition
// We can also use this concept for wrapping components into another component
// ex as same header for all components

const HeaderComp = (props) => {
  return (
    <>
      <h1>Header</h1>
      {props.children}
    </>
  );
};

export default HeaderComp;

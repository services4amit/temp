import React from "react";
import Child1 from "./Child1";
import Child2 from "./Child2";
import HeaderComp from "./HeaderComp";

//building UI from smaller buidling blocks is called composition
// We can also use this concept for wrapping components into another component
// ex as same header for all components. We can use this concept for buliding components having same structure outside


const CompositionEx = () => {
  return (
    <>
      <HeaderComp>
        <Child1></Child1>
      </HeaderComp>
      <HeaderComp>
        
        <Child2></Child2>
      </HeaderComp>
    </>
  );
};

export default CompositionEx;

import React from "react";

//building UI from smaller buidling blocks is called composition
// We can also use this concept for wrapping components into another component
// ex as same header for all components

const Child1 = () => {
  return (
    // <>
    //   <h1>Header</h1>
    //   Child1
    // </>

    <>Child1</>
  );
};

export default Child1;

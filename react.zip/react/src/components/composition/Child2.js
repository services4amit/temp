import React from "react";

//building UI from smaller buidling blocks is called composition
// We can also use this concept for wrapping components into another component
// ex as same header for all components

const Child2 = () => {
  return (
    // <>
    //   <h1>Header</h1>
    //   Child2
    // </>
    <>Child2</>
  );
};

export default Child2;

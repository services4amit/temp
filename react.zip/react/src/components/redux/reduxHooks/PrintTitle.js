import React, { Component,memo } from 'react';
import { connect, useSelector,useDispatch } from 'react-redux';



const PrintTitle = () => {
    // console.log(state)
    console.count("PrintTitle")
    // const name = useSelector(state => state.personal.personal.name);
    const fatherName = useSelector(state => state.personal.personal.father);

    const dispatch = useDispatch();
    return (
        <div>
            PrintTitle
        </div>
    )

}

export default memo(PrintTitle);
// export default PrintTitle;



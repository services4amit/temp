export const updateName=(data)=>{
    return {
        type:'UPDATE_NAME',
        value:data
    }
}

export const updateFatherName=(data)=>{
    return {
        type:'UPDATE_FATHER',
        value:data
    }
}
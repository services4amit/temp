import React, { Component, useState } from "react";
import PrintName from "./PrintName";

//controlled comp: Which comp pass data to display to child comp and
// event handling or any change from child comp also passed to parent Ex: StatefullComp

//uncontrolled comp:is Child comp Ex: Printnamecomp

// statefullcomp : Which has state and manage state Ex: StatefullComp
//stateless comp: which doesnt have state inside  Ex: Printnamecomp

const msg = "Hi React...";
// class StatefullComponent extends Component {
//     // constructor(props) {
//     //     super(props)

//     //     this.state = {
//     //         dropdownValue:'',
//     //         num:20,

//     //         data:
//     //             [
//     //                 { name: "A", age: 20 },
//     //                 { name: "B", age: 22 }
//     //             ]
//     //     }
//     // }

//     state = {
//         dropdownValue: '',
//         data:
//             [
//                 { name: "A", age: 20 },
//                 { name: "B", age: 22 },
//                 { name: "C", age: 22 },
//                 { name: "D", age: 22 },

//             ]
//     }

//     changeName = (data) => {
//         this.setState({
//             data: [
//                 { name: data, age: 20 },
//                 { name: data, age: 22 },

//             ]
//         })
//     }
//     render() {
//         return (
//             <div>
//                 <h1>My Component</h1>
//                  {/* <PrintName name={this.state.data[0].name} age={this.state.data[0].age}></PrintName>

//                 <PrintName name={this.state.data[1].name} age={this.state.data[1].age}></PrintName>  */}

//                 {
//                     this.state.data.map((d) => {

//                         return <PrintName name={d.name} age={d.age}></PrintName>
//                     })

//                 }

//                 {/* <PrintName
//                     name={this.state.data[1].name}
//                     age={this.state.data[1].age}
//                     changeName={this.changeName}
//                 ></PrintName>  */}

//             </div>
//         )
//     };

// }

const StatefullComponent = () => {
  const [data, setData] = useState([
    { name: "A", age: 20 },
    { name: "B", age: 22 },
    { name: "C", age: 22 },
    { name: "D", age: 22 },
  ]);
  const changeName = (name, obj) => {
    console.log("data", name, obj);
    setData(
      data.map((users) => {
        if ((users.age == obj.age)) {
          users.name = name;
        }
        return users;
      })
    );
  };
  return (
    <>
      {data.map((obj) => {
        return (
          <PrintName
            name={obj.name}
            age={obj.age}
            changeName={(data) => changeName(data, obj)}
          ></PrintName>
        );
      })}
    </>
  );
};

export default StatefullComponent;

import React, { Component, useState } from "react";

// class EventHandling extends Component {

//     state = {
//         name: 'Alex',
//         buttonSelected: '',
//         buttons: [
//             { name: "Button1" },
//             { name: "Button2" },
//             { name: "Button3" }
//         ]
//     }

//     // handleChangeName = () => {

//     //     this.setState({
//     //         name: "Mark"
//     //     })
//     // }

//     handleChangeName = (data) => {

//         this.setState({
//             name: data
//         })
//     }

//     // handleChangeNameInput = (evt) => {

//     //     this.setState({
//     //         name: evt.target.value
//     //     })
//     // }

//     handleChangeNameInput = (data) => {

//         console.log(data.target.value)

//         this.setState({
//             name: data.target.value
//         })
//     }

//     handleChangeNameInputNew = (evt) => {
//         this.setState({
//             name: evt
//         })
//         console.log(evt)
//     }

//     // handleChangeNameInputNew=()=>{
//     //     this.setState({
//     //         name: "evt"
//     //     })
//     //     console.log("evt")
//     // }

//     handleButton = (name) => {
//         this.setState({
//             buttonSelected: name
//         })

//     }

//     // handleButton=(name)=>{
//     //     this.setState({
//     //         buttonSelected: name
//     //     })

//     // }

//     render() {

//         return (
//             <div>
//                 <h1>Hi {this.state.name}</h1>

//                 {/*
//                 <button
//                     onClick={this.handleChangeName}>
//                     Change Name</button> */}

//                 {/* <button onClick={() => this.handleChangeName("David")}>Change Name</button> */}

//                 {/* <input
//                     onChange={()=>this.handleChangeNameInputNew("David")}
//                     type="text"></input>
//                 <br></br>
//                 <br></br> */}

//                 {/* <input
//                     onChange={this.handleChangeNameInput}
//                     type="text"></input>
//                 <br></br> */}

//                 <h1>Button selected: {this.state.buttonSelected}</h1>

//                 {
//                     this.state.buttons.map(b => {
//                         return (
//                             <button onClick={() => this.handleButton(b.name)}>{b.name}</button>

//                         )
//                     })
//                 }
//             </div>
//         )
//     };

// }

const EventHandling = () => {
  //     state = {
  //         name: 'Alex',
  //         buttonSelected: '',
  //         buttons: [
  //             { name: "Button1" },
  //             { name: "Button2" },
  //             { name: "Button3" }
  //         ]
  //     }

  const [name, setName] = useState("Alex");
  const [buttonSelected, setButtonSelected] = useState("");
  const [prevbuttonSelected, setPrevButtonSelected] = useState("");

  const buttons = [
    { name: "Button1" },
    { name: "Button2" },
    { name: "Button3" },
  ];

  const handleButton = (name) => {
    setButtonSelected((previousState) => {
        //How to get previous value
      setPrevButtonSelected(previousState);
      return name;
    });
  };

  return (
    <div>
      <h1>Hi {name}</h1>
      <br></br>
      <h1>Button selected: {buttonSelected}</h1>
      <h1>Prev Button selected: {prevbuttonSelected}</h1>
      {buttons.map((b) => {
        return <button onClick={() => handleButton(b.name)}>{b.name}</button>;
      })}{" "}
    </div>
  );
};
export default EventHandling;

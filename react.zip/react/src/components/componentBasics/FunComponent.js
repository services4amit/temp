import React, { Component } from 'react';



// let FunComponent = () => {

   

//    return (

//       <div>
//          <h1>Fucntional Component</h1>
//       </div>
//    )
// }


function FunComponent(){
    return (
        <div>
           <h1>My Functional Component</h1>
        </div>
    )
}



// let FunComponent=(props)=> {

//              return (
//             <div>
//                <h1>My Functional Component</h1>
//                <p>Welcome {props.name} of age {props.age}</p>
//                <p>{props.children}</p>
//             </div>
//         )



// }



export default FunComponent;

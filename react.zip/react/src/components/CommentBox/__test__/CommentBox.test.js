import React from 'react';
import {mount} from 'enzyme';
import ReactShallowRenderer from 'react-test-renderer'
import CommentBox from 'components/CommentBox/CommentBox'


let wrapped
beforeEach(()=>{
     wrapped=mount(<CommentBox></CommentBox>);
});


it('check textbox and button',()=>{
   
    expect(wrapped.find('textarea').length).toEqual(1)
    console.log("length ",wrapped.find('textarea').length)

})

afterEach(()=>{
    wrapped.unmount()
})

it('snapshot testing',()=>{
    // const renderer=new ReactShallowRenderer();
    // ReactShallowRenderer.create(<CommentBox></CommentBox>);
    expect(ReactShallowRenderer.create(<CommentBox></CommentBox>)).toMatchSnapshot();
})
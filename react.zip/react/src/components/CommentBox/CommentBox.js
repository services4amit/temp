import React from 'react'

const CommentBox=()=>{


    return(
        <div>
            CommentBoxNew
            <textarea></textarea>
        </div>
    )
}

export default CommentBox;
import React from 'react'

const CommentList=()=>{


    return(
        <div>
            CommentList
        </div>
    )
}

export default CommentList;
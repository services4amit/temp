

export const ToDoBox = {
    backgroundColor: "#44014C", width: "300px", minHeight: "200px"
}
export const ToDOText = {
    padding: "10px 20px", textAlign: "center", color: "white"
}

// export default Styles;
import React, { Component } from 'react';
import { NavLink } from 'react-router-dom'


class Home extends Component {



    render() {

    

        return (
            <div>

                <div>
                    <h1>Home Page!!!</h1>
                </div>
            </div>
        )
    };


}

export default Home;

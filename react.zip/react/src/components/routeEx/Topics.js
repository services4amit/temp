import React, { Component } from 'react';
import { NavLink } from 'react-router-dom'

class Topics extends Component {


  
    render() {

   
     
        return (
            <div>
                
               <h1>Topics Page!!!</h1>
            </div>
        )
    };


}

export default Topics;

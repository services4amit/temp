import React, { Fragment, useEffect, useState } from "react";
import gql from "graphql-tag";
import { Switch, Route, Redirect, Link, NavLink } from "react-router-dom";
import { graphql, Query } from "react-apollo";
import fetchSong from "./queries/fetchSong";
import fetchJobs from "./queries/fetch-jobs";
// import { useQuery } from "@apollo/client";
// import { useQuery, useMutation } from "@apollo/react-hooks";
import { useQuery, useMutation } from "@apollo/client";
// import { useMutation } from "@apollo/client";

const deleteSong = gql`
  mutation deleteSong($title: String) {
    deleteSong(title: $title) {
      title
    }
  }
`;

const QueryEx = (props) => {
  const { loading, error, data } = useQuery(fetchSong);
  const { loading_fetchJobs, error_fetchJobs, data_fetchJobs } =
    useQuery(fetchJobs);

  console.log("data_fetchJobs ", data_fetchJobs);
  console.log("loading_fetchJobs ", loading_fetchJobs);
  console.log("error_fetchJobs ", error_fetchJobs);

  //   const { loading, error, data ,refetch} = useQuery(fetchSong);

  const updateCache = (cache, { data }) => {
    console.log("cache", typeof cache.readQuery({ query: fetchSong }));
    console.log("cache", cache.readQuery({ query: fetchSong }));
    const list = cache.readQuery({ query: fetchSong });
    cache.writeQuery({
      query: fetchSong,
      data: { songs: [{ __typename: "Song", title: "I1111" }] },
    });
    console.log("data", data);
  };

  const [resData, setResData] = useState({});
  const [deleteSongMut, { loadingMut, errorMut }] = useMutation(deleteSong, {
    // refetchQueries:[{query:fetchSong}],
    // update:updateCache,
    onCompleted: (data, client) => {
      // console.log("completed", client);
      setResData(data.deleteSong);
      //   refetch()
    },
  });

  useEffect(() => {
    // console.log("res data changed");
  }, [resData]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error!</div>;
  // console.log("resData", resData);

  const handleClick = () => {
    // console.log("handle click");

    deleteSongMut({
      variables: {
        title: "dlt",
      },
    });
  };

  return (
    <Fragment>
      <nav>
        <Link to="/QueryEx">QueryEx"</Link>

        <br></br>
        <Link to="/About">About"</Link>
        <br></br>
      </nav>
      QueryEx
      {/* {data.songs.map((d) => {
        return <h1 onClick={handleClick}>{d.title}</h1>;
      })} */}
    </Fragment>
  );
};

// export default graphql(mutation)(graphql(QueryEx)(QueryEx));
export default QueryEx;

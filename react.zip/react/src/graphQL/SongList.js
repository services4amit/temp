import React, { Fragment, useEffect, useState } from "react";
import gql from "graphql-tag";
import { Switch, Route, Redirect, Link, NavLink } from "react-router-dom";
import { graphql } from "react-apollo";
import fetchSong from "./queries/fetchSong";

const SongList = (props) => {
  const [songs, setSongs] = useState([]);

  const [text, setText] = useState(false);

  useEffect(() => {
    if (props.data.songs) {
      setSongs(props.data.songs);
      setText(true);
    }
  }, [props]);

  console.log("props", songs);

  const handleClick = () => {
    console.log("handle click");
    props
      .mutate({
        varibles: {
          title: "wewe",
        },
      })
      .then((data) => {
          props.data.refetch();
        console.log(data);
      });
  };
  return (
    <Fragment>
      <nav>
        <Link to="/SongsList">SongsList"</Link>

        <br></br>
        <Link to="/AddUser">AddUser"</Link>
        <br></br>
      </nav>

      {text
        ? songs.map((d) => {
            return <h1 onClick={handleClick}>{d.title}</h1>;
          })
        : "loading"}
    </Fragment>
  );
};

const mutation = gql`
  mutation deleteSong($title: String) {
    deleteSong(title: $title) {
      title
    }
  }
`;

export default graphql(mutation)(graphql(fetchSong)(SongList));

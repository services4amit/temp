import React, { Component } from "react";

import { Switch, Route, Redirect } from "react-router-dom";
import SongsList from "./SongList";
import AddUser from "./AddUser";
import QueryEx from './QueryEx';
import About from './About'
class GraphQLRoutes extends Component {
  render() {
    return (
      <Switch>
        <Route component={About} exact path="/About" />
        <Route component={QueryEx} exact path="/QueryEx"/>
        <Route component={SongsList} exact path="/SongsList" />
        <Route component={AddUser} exact path="/AddUser" />
        <Route path="/" component={SongsList}></Route>
      </Switch>
    );
  }
}

export default GraphQLRoutes;

// const { Fragment } = require("react")

import React, { Fragment, useEffect, useState } from "react";
import gql from "graphql-tag";
import { graphql } from "react-apollo";
import { Switch, Route, Redirect, Link, NavLink } from "react-router-dom";
import fetchSong from './queries/fetchSong'

const AddUser = (props) => {
  const handleSubmit = (event) => {
      console.log("insdie handlesubmit")
    // event.preventDefault();
    props.mutate({
      variables: {
        firstname: "wewe",
        age: 21,
        companyId: "apple",
      },
      refetchQueries:[{query:fetchSong}]
    }).then((data)=>console.log("18",data));
  };

  return (
    <Fragment>
           <nav>
        <Link to="/SongsList">SongsList"</Link>

        <br></br>
        <Link to="/AddUser">AddUser"</Link>
        <br></br>
      </nav>
      ADD USER<br></br>
      <span>Name</span>
      <input></input>
      <br></br>
      <span>Age</span>
      <input></input>
      <br></br>
      <span>Company</span>
      <input></input>
      <br></br>
      <button onClick={handleSubmit}>Submit</button>
    </Fragment>
  );
};

const mutatation = gql`
  mutation addUser($firstname: String!, $age: Int, $companyId: String) {
    addUser(firstName: $firstname, age: $age, companyId: $companyId) {
      id
      company {
        companyName
      }
    }
  }
`;

export default graphql(mutatation)(AddUser);

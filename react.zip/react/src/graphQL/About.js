import React, { Fragment, useEffect, useState } from "react";
import gql from "graphql-tag";
import { Switch, Route, Redirect, Link, NavLink } from "react-router-dom";

const About=()=>{
    return(
        <Fragment>
            <nav>
        <Link to="/QueryEx">QueryEx"</Link>

        <br></br>
        <Link to="/AddUser">AddUser"</Link>
        <br></br>
      </nav>
      <h1>About Page</h1>
        </Fragment>
        
    )
}

export default  About
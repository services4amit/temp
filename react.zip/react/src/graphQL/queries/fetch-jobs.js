import gql from "graphql-tag";
// export default gql`
//   {
//     jobs {
//       description
//     }
//   }
// `;

export default gql`
  query JobQuery($id: ID!) {
    jobById(id: $id) {
      description
    }
  }
`;

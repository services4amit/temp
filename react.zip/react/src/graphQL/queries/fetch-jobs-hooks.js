import { useQuery, useMutation } from "@apollo/client";
import fetchJobs from "./fetch-jobs";
export default function useGetJobs(id) {
  const { loading, error, data } = useQuery(fetchJobs, {
    variables: { id },
  });

  return {
    loading,
    error,
    data,
  };
}

import React from "react";
import axios from "axios";

const Download = () => {
  const handle = async () => {
    console.log("dfdff");
    const fileResponse = await axios.get(
      "https://s3-external-1.amazonaws.com/media.twiliocdn.com/AC981d17bd120107c456ed167cf5dc2284/adae5224710a38771dd146a2e1734173",
      { responseType: "blob" }
    );
    // const url = window.URL.createObjectURL(new Blob([fileResponse.data]));
    const url = window.URL.createObjectURL(fileResponse.data);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "fileName");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  // window.onafterprint
  return (
    <div>
      <h1 onClick={() => handle()}>Download</h1>
      <button>DDDDDDD</button>
    </div>
  );
};

export default Download;

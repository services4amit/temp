let obj = [
  {
    id: 1,
    type: "ADD",
  },
  {
    id: 1,
    type: "CHANGE",
  },
  {
    id: 2,
    type: "ADD",
  },
  {
    id: 3,
    type: "ADD",
  },
  {
    id: 3,
    type: "CHANGE",
  },
  {
    id: 2,
    type: "REMOVE",
  },
  {
    id: 3,
    type: "CHANGE",
  },
  {
    id: 1,
    type: "REMOVE",
  },
];

let res = obj.reduce((sum, cur) => {
  // console.log(cur, sum);
  if (sum[cur.id]) {
    sum[cur.id].push(cur.type);
  } else {
    sum[cur.id] = [cur.type];
  }

  return sum;
}, {});
console.log(res);
let r = Object.keys(res).map((obj) => {
  return { id: obj, type: res[obj] };
});
console.log(r);

import React from "react";
import ReactDOM from "react-dom";
// import ApolloClient from "apollo-client";

// import { ApolloClient, InMemoryCache } from "@apollo/client";
import {
  ApolloClient,
  InMemoryCache,
  ApolloProvider,
  gql,
} from "@apollo/client";
// import { ApolloProvider } from "react-apollo";
// import { ApolloProvider } from "@apollo/client";
// import { ApolloProvider } from "@apollo/react-hooks";
import "./index.css";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
import AppWithRoutes from "./AppWithRoutes";
import AppRouterEx from "./AppRouterEx";
import ReduxRouter from "./ReduxRouter";
import { Router } from "react-router-dom";
import { createBrowserHistory } from "history";
import { Provider } from "react-redux";
import mystore from "./components/redux/Store";
import SongList from "./graphQL/SongList";
import GraphQLRoutes from "./graphQL/GraphQLRoutes";
const browserHistory = createBrowserHistory();

// To know how react works:

//Rendering the element is decided by ReactDOM
// There will be diff rendering process for browser, native devices ,VR environments
//ex: React VR, React native , electron etc ...
// const element = React.createElement("h1", null, "hello world");
// console.log(element)
// ReactDOM.render(
//   element,
//   document.getElementById('root')
// );

//Another example:
// ReactDOM.render(
//   <h1>
//    hello world!!
//    </h1>,
//   document.getElementById('root')
// );

//Components code with all concepts example:
ReactDOM.render(
  <Router history={browserHistory}>
    <AppWithRoutes></AppWithRoutes>
  </Router>,
  document.getElementById("root")
);

//Router example Codes:
// ReactDOM.render(
//   <Router history={browserHistory}>
//     <AppRouterEx></AppRouterEx>
//   </Router>,
//   document.getElementById('root')

// );

//Redux code
// ReactDOM.render(
//   <Provider store={mystore}>
//     <Router history={browserHistory}>
//       <ReduxRouter />
//     </Router>
//   </Provider>,
//   document.getElementById("root")
// );

//Appolo Code

// const client = new ApolloClient({
//   uri: "http://localhost:4000/graphql",
//   cache: new InMemoryCache(),
// });

// ReactDOM.render(
//   <ApolloProvider client={client}>
//     <Router history={browserHistory}>
//       <GraphQLRoutes></GraphQLRoutes>
//     </Router>
//   </ApolloProvider>,

//   document.getElementById("root")
// );

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
